class City < ActiveRecord::Base
  belongs_to :country
end
