class WelcomeController < ApplicationController
  layout "application"
  
end
